package com.quadromedalhasolimpiadas.olimpics.model.enumeration;

public enum TipoMedalha {
	OURO, 
	PRATA,
	BRONZE
}
