package com.quadromedalhasolimpiadas.olimpics.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quadromedalhasolimpiadas.olimpics.model.dto.UsuarioDto;
import com.quadromedalhasolimpiadas.olimpics.services.UsuarioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@RestController
@RequestMapping(value = "/usuario")
public class UsuarioController {
	
	@Autowired
	UsuarioService usuarioService;
	
	
	@Operation(description = "Busca todos usuarios da aplicação")
	@ApiResponse(description = "retorna um Page com todos usuarios cadastrados na aplicação")
	@GetMapping
	public Page<UsuarioDto> todosUsuarios(Pageable pag){
		return usuarioService.todosUsuarios(pag);
	}
	
	@PostMapping
	public ResponseEntity<UsuarioDto> salvar(@RequestBody @Valid UsuarioDto usuarioDto) {
		
		UsuarioDto usuarioDtoSalvo = usuarioService.salvar(usuarioDto);
		
		
		return ResponseEntity.ok(usuarioDtoSalvo);
	}
	
	@SuppressWarnings("unchecked")
	@DeleteMapping("/{id}")
	@Transactional
	@Secured("ROLE_ADMIN")
	public ResponseEntity<UsuarioDto> deletar(@PathVariable Long id) {

		return usuarioService.deletar(id)?   (ResponseEntity<UsuarioDto>) ResponseEntity.ok() : ResponseEntity.notFound().build();
	}
	
	
}
