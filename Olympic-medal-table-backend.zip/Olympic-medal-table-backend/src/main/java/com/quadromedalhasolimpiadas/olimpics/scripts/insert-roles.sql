INSERT INTO roles (id,role) VALUES
(1,'ADMIN'), ( 2, 'USER');