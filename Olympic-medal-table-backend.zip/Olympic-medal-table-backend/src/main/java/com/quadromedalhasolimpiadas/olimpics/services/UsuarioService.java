package com.quadromedalhasolimpiadas.olimpics.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.quadromedalhasolimpiadas.olimpics.model.dto.UsuarioDto;
import com.quadromedalhasolimpiadas.olimpics.model.entities.Usuario;
import com.quadromedalhasolimpiadas.olimpics.repositories.UsuarioRepository;

@Service
public class UsuarioService {

	@Autowired
	UsuarioRepository usuarioRepository;
	
	 @Autowired
	 private PasswordEncoder passwordEncoder;
	
	public Page<UsuarioDto> todosUsuarios(Pageable pag){
		return usuarioRepository.findAll(pag).map(UsuarioDto::new);
	}
	
	public UsuarioDto salvar(UsuarioDto usuarioDto) {

		Usuario usuario = new Usuario(usuarioDto);
		String senha = usuario.getSenha();
		usuario.setSenha(passwordEncoder.encode(senha));
		usuarioRepository.save(usuario);
		return new UsuarioDto(usuario);
	}
	
	public Boolean deletar(Long id) {
		var usuario = usuarioRepository.findById(id);
		if (usuario.isPresent()) {
			usuarioRepository.delete(usuario.get());
			return true;
		}
		return false;
	}
	
}
