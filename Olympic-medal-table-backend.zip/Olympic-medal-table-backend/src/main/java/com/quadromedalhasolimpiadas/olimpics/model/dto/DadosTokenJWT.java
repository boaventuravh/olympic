package com.quadromedalhasolimpiadas.olimpics.model.dto;

public record DadosTokenJWT(String token) {

}