package com.quadromedalhasolimpiadas.olimpics.model.enumeration;

public enum TipoUsuario {
	ADMINISTRADOR,
	COMUM
}
